# NosoWallet
Noso Windows Wallet

Official Release Ver 0.2.0K

April 1, 2021

THIS IS AM OFFICIAL RELEASE

Requirements:

Library Indy 10

DCPCrypt

HashLib4PascalPackage

SimpleBaseLib4PascalPackage

CryptoLib4PascalPackage

This librarys are in the Packages folder (rar files) 

Tested on Windows 7, 8.1 and 10

Tested runs on uUbuntu usings Wine

How to built.

Download lazarus IDE from https://www.lazarus-ide.org/index.php?page=downloads

Install lazarus

Run lazarus. Package > Online Package Manager.

Select the packages mentioned above and then click install.

File > Open > Select the .LPI file from this repository.

To compile, just click CTRL+F9; it will create the .EXE file in the same folder

Donations for the project:

BTC: 3H1VzdL3QFQpc62DUhbtCFV5dG4K1yPwVB

LTC: LUUWwzfeQtJ4dc8A5xJVz3Zacray55f1WH

Paypal: scalvhh@hotmail.com

NosoCoin:  devteam_donations
